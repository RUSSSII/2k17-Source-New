#pragma once

#include <windows.h>

#undef min
#undef max

#undef GetProp